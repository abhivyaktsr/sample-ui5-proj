sap.ui.define([
	"islm/sample_project/test/unit/controller/View1.controller"
], function () {
  "use strict";
});